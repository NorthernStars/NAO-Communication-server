#!/bin/bash

nohup python /home/nao/naocom/communication_server.py > /dev/null 2>&1 &
