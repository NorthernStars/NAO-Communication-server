'''
Created on 27.08.2014

@author: hannes
'''

JOINTS = {
    'BODY ':  "Body",
     
    'HEAD ':  "Head",
    'HEAD_YAW ':  "HeadYaw",
    'HEAD_PITCH ':  "HeadPitch",
    
    'LEFT_ARM ':  "LArm",
    'LEFT_HAND ':  "LHand",     
    'LEFT_LEG ':  "LLeg",

    'RIGHT_LEG ':  "RLeg",     
    'RIGHT_ARM ':  "RArm",
    'RIGHT_HAND ':  "RHand",
}